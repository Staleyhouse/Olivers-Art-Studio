# Ollie’s Art Studio — GitHub Pages edition

Upload the **contents** of this ZIP to the root of a new public GitHub repository (not the ZIP itself). In Settings → Pages, select Deploy from a branch, `main`, `/ (root)`, and Save. Wait for the published HTTPS URL, open it in iPad Safari, then Share → Add to Home Screen.

This edition keeps the seven realistic art categories and drawing tools, adds installable PWA assets and offline app shell, and improves pointer handling. The Unsplash API requires your own key; uploads work without it. Browser-based checks are not a substitute for testing Apple Pencil on a physical iPad. Drawing data saved in browser storage may be lost if website data is cleared; export important artwork.

# Ollie’s Art Studio — rebuilt

## Open in a browser
Open `index.html` in Chrome, Safari, Edge or Firefox. The drawing tools, photo upload, lesson browser, PNG export and sketchbook work without a server.

## Install on iPad with GitHub Pages
1. Create a **public** GitHub repository named `ollies-art-studio`.
2. Upload the **contents** of this ZIP, with `index.html` in the repository root (not inside a nested folder).
3. In repository **Settings → Pages**, select **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
4. Once published, open `https://YOUR-USERNAME.github.io/ollies-art-studio/` in iPad Safari.
5. Tap Share → Add to Home Screen → Add.

The PWA needs HTTPS hosting for offline installation. A local HTML file can be used in a desktop browser, but iPad Files preview is not a reliable way to execute an interactive web app.

## Notes
- Drawing uses native pointer events and fixed-resolution canvas, supporting Apple Pencil, finger and mouse.
- Photos are local-only. No Unsplash key is needed; upload a real photo for reference.
- Sketchbook saves up to 12 compressed images in browser local storage. Export important drawings as PNG files. Clearing site data removes local sketchbook entries.
- 35 lessons across 7 categories, with 5 instructional steps each. Lessons teach techniques; there are no built-in photorealistic step illustrations.
